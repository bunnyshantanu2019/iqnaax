from django.shortcuts import render,redirect
from django.views import View
from .forms import CustomerRegistrationForm,CustomerProfileForm,ContactInfoForm
from django.contrib import messages
from .models import Customer,Product,Cart
from django.contrib.auth.models import User
from django.db.models import Q
from django.http import JsonResponse
from django.contrib.auth.decorators import login_required
from django.utils.decorators import method_decorator


def index(request):
    return render(request, 'index.html')

def about(request):
    return render(request, 'about.html')

def blog(request):
    return render(request, 'blog.html')

def gallery(request):
    return render(request, 'gallery.html')

def shop(request):
    return render(request, 'shop.html')

def contact(request):
    return render(request, 'contact.html')

class ContactInfoView(View):
    def get(self, request):
       form = ContactInfoForm()
       return render(request, 'contact.html',{'form':form})
    
    def post(self, request):
       form = ContactInfoForm(request.POST)
       if form.is_valid():
          messages.success(request, 'Congratulations!! Registered Successfully')
          form.save()
          return redirect('contact')
       return render(request, 'contact.html',{'form':form})

def products(request):
    return render(request, 'product.html')

def TandC(request):
    return render(request, 'termandcond.html')

def dashboard(request):
    return render(request, 'dashboard.html')

class CustomerRegistrationView(View):
    def get(self, request):
       form = CustomerRegistrationForm()
       return render(request, 'customerregistration.html',{'form':form})
    
    def post(self, request):
       form = CustomerRegistrationForm(request.POST)
       if form.is_valid():
          messages.success(request, 'Congratulations!! Registered Successfully')
          form.save()
          return redirect('registration')
       return render(request, 'customerregistration.html',{'form':form})

@method_decorator(login_required, name='dispatch')
class ProfileView(View):
    def get(self, request):
       form = CustomerProfileForm()
       return render(request, 'profile.html', {'form':form, 'active':'btn-primary'})
    
    def post(self, request):
        form = CustomerProfileForm(request.POST)
        if form.is_valid():
            usr = request.user
            name = form.cleaned_data['name']
            locality = form.cleaned_data['locality']
            city = form.cleaned_data['city']
            zipcode = form.cleaned_data['zipcode']
            state = form.cleaned_data['state']
            reg = Customer(user=usr, name=name, locality=locality, city=city, zipcode=zipcode, state=state)
            reg.save()
            messages.success(request, 'Conguratioulations!! Profile Upadated Successfully')
            return redirect('profile')
        return render(request, 'profile.html', {'form':form, 'active':'btn-primary'})
    
@login_required
def address(request):
    add = Customer.objects.filter(user=request.user)
    return render(request, 'address.html', {'add':add, 'active':'btn-primary'})

def product_list(request):
    products = Product.objects.all()
    return render(request, 'steam.html', {'products': products})


class ProductDetailView(View):
    def get(self, request, pk):
        totalitem = 0
        prod = Product.objects.get(pk=pk)
        products = Product.objects.all()
        item_already_in_cart = False
        if request.user.is_authenticated:
            totalitem = len(Cart.objects.filter(user=request.user))
            item_already_in_cart = Cart.objects.filter(Q(product=prod .id) & Q(user=request.user)).exists()
            
        return render(request, 'productDetails.html', {'prod': prod,'products': products, 'item_already_in_cart': item_already_in_cart,'totalitem':totalitem})


def empty(request):
    return render(request, 'empty.html')

@login_required
def add_to_cart(request):
    user=request.user
    product_id = request.GET.get('prod_id')
    product = Product.objects.get(id=product_id)
    Cart(user=user, product=product).save()
    return redirect('/cart')

@login_required
def show_cart(request):
    totalitem = 0
    if request.user.is_authenticated:
        totalitem = len(Cart.objects.filter(user=request.user))
        user=request.user
        cart = Cart.objects.filter(user=user)
        amount = 0.0
        # shipping_amount = 70.0
        total_amount = 0.0
        cart_product = [p for p in Cart.objects.all() if p.user == user]
        #print(cart_product)

        if cart_product:
            for p in cart_product:
                tempamount = (p.quantity * p.product.discounted_price)
                amount += tempamount
                totalamount = amount 
                # + shipping_amount
            return render(request, 'addtocart.html', {'carts':cart, 'totalamount':totalamount, 'amount':amount,'totalitem':totalitem})
        else:
            return render(request, 'empty.html')
    
@login_required
def plus_cart(request):
    if request.method == 'GET':
        prod_id = request.GET['prod_id']
        c = Cart.objects.get(Q(product=prod_id) & Q(user=request.user))
        c.quantity+=1
        c.save()
        amount = 0.0
        # shipping_amount = 70.0
        cart_product = [p for p in Cart.objects.all() if p.user == request.user]
        for p in cart_product:
                tempamount = (p.quantity * p.product.discounted_price)
                amount += tempamount
               

        data = {
            'quantity': c.quantity,
            'amount': amount,
            'totalamount':amount 
            # + shipping_amount
            }
        return JsonResponse(data)
    
@login_required
def minus_cart(request):
    if request.method == 'GET':
        prod_id = request.GET['prod_id']
        c = Cart.objects.get(Q(product=prod_id) & Q(user=request.user))
        c.quantity-=1
        c.save()
        amount = 0.0
        # shipping_amount = 70.0
        cart_product = [p for p in Cart.objects.all() if p.user == request.user]
        for p in cart_product:
                tempamount = (p.quantity * p.product.discounted_price)
                amount += tempamount
              

        data = {
            'quantity': c.quantity,
            'amount': amount,
            'totalamount':amount 
            # + shipping_amount
            }
        return JsonResponse(data)

@login_required 
def remove_cart(request):
    if request.method == 'GET':
        prod_id = request.GET['prod_id']
        c = Cart.objects.get(Q(product=prod_id) & Q(user=request.user))
        c.delete()
        amount = 0.0
        # shipping_amount = 70.0
        cart_product = [p for p in Cart.objects.all() if p.user == request.user]
        for p in cart_product:
                tempamount = (p.quantity * p.product.discounted_price)
                amount += tempamount
             

        data = {
            'amount': amount,
            'totalamount':amount 
            # + shipping_amount
            }
        return JsonResponse(data)

@login_required
def checkout(request):
    user = request.user
    add = Customer.objects.filter(user=user)
    cart_items = Cart.objects.filter(user=user)
    amount = 0.0
    # shipping_amount = 70.0
    totalamount = 0.0
    cart_product = [p for p in Cart.objects.all() if p.user == request.user]
    if cart_product:
        for p in cart_product:
            tempamount = (p.quantity * p.product.discounted_price)
            amount += tempamount
        totalamount=amount 
        # + shipping_amount
    return render(request, 'checkout.html', {'add':add, 'totalamount':totalamount, 'cart_items':cart_items})

def blogDetails1(request):
    return render(request, 'blogDetails.html')

def blogDetails2(request):
    return render(request, 'blogDetail_2.html')

def blogDetails3(request):
    return render(request, 'blogDetail_3.html')


def shop_steam_kits(request):
    return render(request, 'shop_steam_kits.html')

def LabProducts(request, pk):
    product = Product.objects.get(pk=pk)
    return render(request, 'labproducts.html', {'product': product})

class LabProductDetailView(View):
    def get(self, request, pk):
        totalitem = 0
        prod = Product.objects.get(pk=pk)
        products = Product.objects.all()
        item_already_in_cart = False
        if request.user.is_authenticated:
            totalitem = len(Cart.objects.filter(user=request.user))
            item_already_in_cart = Cart.objects.filter(Q(product=prod .id) & Q(user=request.user)).exists()
            
        return render(request, 'labproductsdetails.html', {'prod': prod,'products': products, 'item_already_in_cart': item_already_in_cart,'totalitem':totalitem})


def PrivayPolicy(request):
    return render(request, 'privacyPolicy.html')















        


