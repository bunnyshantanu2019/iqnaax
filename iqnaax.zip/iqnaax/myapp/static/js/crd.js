
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    $(document).ready(function() {
        $(".increment").on("click", function() {
            var $product = $(this).closest(".product");
            var $quantity = $product.find(".quantity");
            var $price = parseFloat($product.find("p").text().replace("Price: $", ""));
            var currentQuantity = parseInt($quantity.text());

            currentQuantity++;
            $quantity.text(currentQuantity);

            // Add the item to the cart
            $("#cart-items").append("<li>" + $product.find("h2").text() + " x" + currentQuantity + "</li>");

            // Calculate and update the cart total
            var cartTotal = parseFloat($("#cart-total").text());
            cartTotal += $price;
            $("#cart-total").text(cartTotal.toFixed(2));
        });

        $(".decrement").on("click", function() {
            var $product = $(this).closest(".product");
            var $quantity = $product.find(".quantity");
            var $price = parseFloat($product.find("p").text().replace("Price: $", ""));
            var currentQuantity = parseInt($quantity.text());

            if (currentQuantity > 0) {
                currentQuantity--;
                $quantity.text(currentQuantity);

                // Remove the item from the cart
                $("#cart-items li:contains(" + $product.find("h2").text() + ")").remove();

                // Calculate and update the cart total
                var cartTotal = parseFloat($("#cart-total").text());
                cartTotal -= $price;
                $("#cart-total").text(cartTotal.toFixed(2));
            }
        });
    });
