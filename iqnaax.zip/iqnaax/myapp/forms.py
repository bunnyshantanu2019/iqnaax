from django import forms
from django.contrib.auth.forms import UserCreationForm,AuthenticationForm,UsernameField,PasswordResetForm,PasswordChangeForm,SetPasswordForm
from django.contrib.auth.models import User
from django.utils.translation import gettext,gettext_lazy as _
from django.contrib.auth import password_validation
from .models import Customer,ContactInfo
from django.core import validators

class CustomerRegistrationForm(UserCreationForm):   
    password1 = forms.CharField(label="Password", widget=forms.PasswordInput(attrs={'class':'form-control', 'id':'ibtn'}))
    
    password2 = forms.CharField(label="Confirm Password (again)", widget=forms.PasswordInput(attrs={'class':'form-control','id':'ibtn'}))
    
    email = forms.CharField(required=True, label="Email",widget=forms.EmailInput(attrs={'class':'form-control','id':'ibtn'}))
    
    class Meta:
        model = User
        fields = ['username', 'email', 'password1', 'password2']
        widgets = {'username': forms.TextInput(attrs={'class':'form-control','id':'ibtn'})}
        error_messages = {'username':{'required':'Userame is Required'}, 
                          'email':{'required':'Email is Required'}, 
                          'password1':{'required':'Password is Required'}, 
                          'password2':{'required':'Confirm password is Required'}, 
                          
                          }
        
        
class LoginForm(AuthenticationForm):
    username = UsernameField(widget=forms.TextInput(attrs={"autofocus": True, 'class':'form-control','id':'ibtn'}))
    password = forms.CharField(label=_("Password"),strip=False,
    widget=forms.PasswordInput(attrs={"autocomplete": "current-password", 'class':'form-control','id':'ibtn'}))
    error_messages = {'username':{'required':'Username is Required'}, 
                        'password':{'required':'Password is Required'}
                        }
    
class MyPasswordResetForm(PasswordResetForm):
     email = forms.EmailField(
        label=_("Email"),
        max_length=254,
        widget=forms.EmailInput(attrs={"autocomplete": "email", 'class':'form-control ', 'id':'ibtn'}),
        error_messages = {'name':{'required':'Name is Required'},}
    )
     
     
class CustomerProfileForm(forms.ModelForm):
    class Meta:
        model = Customer
        fields = ['name', 'locality', 'city', 'zipcode', 'state']
        widgets = {'name': forms.TextInput(attrs={'class':'form-control', 'id':'ibtn'
        }), 'locality':forms.TextInput(attrs={'class':'form-control', 'id':'ibtn'}),
        'city':forms.TextInput(attrs={'class':'form-control', 'id':'ibtn'}),
        'zipcode':forms.NumberInput(attrs={'class':'form-control', 'id':'ibtn'}),
        'state':forms.Select(attrs={'class':'form-control', 'id':'ibtn'})}


class MyPasswordChangeForm(PasswordChangeForm):
    old_password = forms.CharField(
        label=_("Old password"),
        strip=False,
        widget=forms.PasswordInput(
            attrs={"autocomplete": "current-password", "autofocus": True, 'class':'form-control', 'id':'ibtn'}
        ),
    )

    new_password1 = forms.CharField(
        label=_("New Password"),
        widget=forms.PasswordInput(
            attrs={"autocomplete": "new-password",  'class':'form-control', 'id':'ibtn'}
        ),
        strip=False,
        help_text=password_validation.password_validators_help_text_html(),
    )

    new_password2 = forms.CharField(
        label=_("Confirm New Password"),
        widget=forms.PasswordInput(attrs={"autocomplete": "new-password", 'class':'form-control', 'id':'ibtn'}),
        strip=False,
    )


     
class MySetPasswordForm(SetPasswordForm):
    new_password1 = forms.CharField(
        label=_("New password"),
        widget=forms.PasswordInput(attrs={"autocomplete": "new-password", 'class':'form-control', 'id':'ibtn'}),
        strip=False,
        help_text=password_validation.password_validators_help_text_html(),
    )
    new_password2 = forms.CharField(
        label=_("Confirm New Password"),
        strip=False,
        widget=forms.PasswordInput(attrs={"autocomplete": "new-password", 'class':'form-control', 'id':'ibtn'}),
    )

class ContactInfoForm(forms.ModelForm):
    class Meta:
        model = ContactInfo
        fields = ['name', 'email', 'phone', 'message']
        widgets = {'name': forms.TextInput(attrs={'class':'form-control'}),
                   'email': forms.EmailInput(attrs={'class':'form-control'}),
                   'phone': forms.NumberInput(attrs={'class':'form-control'}),
                   'message': forms.Textarea(attrs={'class':'form-control'}),
                   }
        error_messages = {'name':{'required':'Name is Required'}, 
                          'email':{'required':'Email is Required'}, 
                          'phone':{'required':'Phone is Required'}, 
                          'message':{'required':'Message is Required'}, 
                          
                          }
        
    
    