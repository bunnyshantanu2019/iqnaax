from django.urls import path
from .import views
from django.conf import settings
from django.conf.urls.static import static
from django.contrib.auth import views as auth_views
from .forms import LoginForm,MyPasswordResetForm,MyPasswordChangeForm,MySetPasswordForm

urlpatterns = [
    path('', views.index, name='index'),
    path('about.py/', views.about, name='about'),
    path('blog.py/', views.blog, name='blog'), 
    path('blog_detail_1/', views.blogDetails1, name='blog1'), 
    path('blog_detail_2/', views.blogDetails2, name='blog2'), 
    path('blog_detail_3/', views.blogDetails3, name='blog3'), 
    path('gallery.py/', views.gallery, name='gallery'), 
    path('shop.py/', views.shop, name='shop'), 
    path('shop-steam-kits/', views.shop_steam_kits, name='shop-steam-kits'),
    
    path('contact.py/', views.ContactInfoView.as_view(), name='contact'), 
    path('registration/',views.CustomerRegistrationView.as_view(), name='registration'),
    path('accounts/login/', auth_views.LoginView.as_view(template_name='login.html',
        authentication_form=LoginForm), name='login'),
    
    path('password_reset/', auth_views.PasswordResetView.as_view(template_name='password_reset.html', form_class=MyPasswordResetForm), name='password_reset'),

    path('steam.py/', views.product_list, name='steam'),
    
    path('product-detail/<int:pk>', views.ProductDetailView.as_view(), name='product-detail'),
    
    path('empty/', views.empty, name='empty'),
    
    path('add-to-cart/', views.add_to_cart, name='add-to-cart'),
  
    path('cart/',views.show_cart, name='cart'),
    path('pluscart/', views.plus_cart),
    path('minuscart/', views.minus_cart),
    path('removecart/', views.remove_cart),
    path('checkout/', views.checkout, name='checkout'),
    
    path('labproducts/<int:pk>/', views.LabProducts, name='labproducts'),
    path('lab-product-detail/<int:pk>/', views.LabProductDetailView.as_view(), name='lab-product-detail'),
    
    path('t&c.py/', views.TandC, name='t&c'), 
    path('privacy-policy/', views.PrivayPolicy, name='privacy-policy'), 
    
    path('profile/', views.ProfileView.as_view(), name='profile'),
    path('address/', views.address, name='address'),
        

    path('passwordchange/', auth_views.PasswordChangeView.as_view(template_name='passwordchange.html',
        form_class=MyPasswordChangeForm, success_url='/passwordchangedone/'), name='passwordchange'),

    path('passwordchangedone/', auth_views.PasswordChangeView.as_view(template_name='passwordchangedone.html'), name='passwordchangedone'),

    path('password-reset/done/', auth_views.PasswordResetDoneView.as_view(template_name='password_reset_done.html'), name='password_reset_done'),
    
    path('password-reset-confirm/<uidb64>/<token>/', auth_views.PasswordResetConfirmView.as_view(template_name='password_reset_confirm.html', form_class=MySetPasswordForm), name='password_reset_confirm'),

    path('password-reset-complete/', auth_views.PasswordResetCompleteView.as_view(template_name='password_reset_complete.html'), name='password_reset_complete'),
    
    path('logout/', auth_views.LogoutView.as_view(next_page='login'), name='logout'),
   
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)  
 

    


 

